local imgui = require 'imgui'
local encoding = require 'encoding'
local sampev = require 'lib.samp.events'
encoding.default = 'CP1251'
u8 = encoding.UTF8

local window, offlineDay, waitKick = imgui.ImBool(false), imgui.ImInt(3), imgui.ImInt(800)
local state = false
members = {}

function main()
    while not isSampAvailable() do wait(0) end
    sampAddChatMessage('[OFFLINE CLEANER]: {FFFFFF}Loaded. Commands: {1ceb9b}/offclean{FFFFFF}. Author: {1ceb9b}Yondime', 0xFF1ceb9b)
    sampRegisterChatCommand('offclean', function(arg) window.v = not window.v imgui.Process = window.v end)
    wait(-1)
end

function sampev.onShowDialog(id, style, title, button1, button2, text)
    if checking and title:find('���������%s�����%s%(') then
        local i, isNext = 0, false
        for n in text:gmatch('[^\r\n]+') do
            if n:find('([a-zA-Z_]+)%s%(%d+%).+%s(%d+)%s����') then
                printStringNow('~r~CHECKING', 100)
                local nick, days = n:match('([a-zA-Z_]+)%s%(%d+%).+%s(%d+)%s����')
                if tonumber(days) >= offlineDay.v then
                    local isFound = false
                    for d, g in pairs(members) do if nick == members[d]['name'] then isFound = true end end
                    if not isFound then table.insert( members,{name = nick, day = days, kicks = true}) end
                elseif tonumber(days) < offlineDay.v then
                    checking, isNext = false, true
                    sampSendDialogResponse(id,0,0)
                    sampAddChatMessage('[OFFLINE CLEANER]: {FFFFFF}Stop checking.', 0xFF1ceb9b)
                    break
                end
            end
            if n:find('>>>') then sampSendDialogResponse(id, 1, i-1) isNext = true i = 0 end
            i = i + 1
        end
        if not isNext then checking = false sampSendDialogResponse(id,0,0) sampAddChatMessage('[OFFLINE CLEANER]: {FFFFFF}Stop checking.', 0xFF1ceb9b) end 
        return false
    end
end

function kick(days, delay)
    for d, t in pairs(members) do 
        if days <= tonumber(members[d]['day']) and members[d]['kicks'] then
            sampSendChat('/famoffkick '..members[d]['name'])
            wait(delay)
        end
    end
    sampAddChatMessage('[OFFLINE CLEANER]: {FFFFFF}Cleaning process is finished', 0xFF1ceb9b)
end

function imgui.OnDrawFrame()
    if window.v then
        imgui.SetNextWindowPos(imgui.ImVec2(400.0, 350.0), imgui.Cond.FirstUseEver)
        imgui.SetNextWindowSize(imgui.ImVec2(350, 400), imgui.Cond.FirstUseEver)
        imgui.Begin('Offline Members Cleaner || Author: Yondime', window, imgui.WindowFlags.NoResize)
        if imgui.Button('CHECK OFFLINE', imgui.ImVec2(100, 40)) then
            if offlineDay.v ~= nil then
                checking, members = not checking, {}
                sampAddChatMessage(checking and '[OFFLINE CLEANER]: {FFFFFF}Started checking offline members. Open FAMMENU and Press button - {1ceb9b}�FAMILY MEMBERS OFFLINE�' or '[OFFLINE CLEANER]: {FFFFFF}Stoped.', 0xFF1ceb9b)
            else
                sampAddChatMessage('[OFFLINE CLEANER]: {FFFFFF}Error argument. Try entering the numbers.', 0xFF1ceb9b)
                if checking then checking = false end 
            end
        end
        imgui.SameLine()
        if imgui.Button('KICK OFFLINE', imgui.ImVec2(130, 40)) then
            if #members ~= 0 then
                state = not state
                sampAddChatMessage(state and '[OFFLINE CLEANER]: {FFFFFF}Started cleaning offline members. Waiting.' or '[OFFLINE CLEANER]: {FFFFFF}Stoped.', 0xFF1ceb9b)
                lua_thread.create(kick, offlineDay.v, waitKick.v)
            else
                sampAddChatMessage('[OFFLINE CLEANER]: {FFFFFF}Check list of offline players. Use button on right {1ceb9b}�CHECK OFFLINE�', 0xFF1ceb9b)
            end
        end
        imgui.PushItemWidth(40)
        imgui.SetCursorPos(imgui.ImVec2(255, 20))
        imgui.InputInt("days", offlineDay, 0, 0) 
        imgui.SetCursorPos(imgui.ImVec2(255, 45))
        imgui.InputInt('wait', waitKick,0,0)
        imgui.PopItemWidth()
        for d, t in pairs(members) do 
            if offlineDay.v <= tonumber(members[d]['day']) then
                if imgui.Checkbox('##'..d, imgui.ImBool(members[d]['kicks'])) then members[d]['kicks'] = not members[d]['kicks'] end
                imgui.Text(u8(d..'. '..members[d]['name']..'| Offline: '..members[d]['day']), imgui.SameLine())
            end
        end
        imgui.End()
    else
        imgui.Process = window.v
    end
end

function setLightStyle()
    imgui.SwitchContext()
    local style = imgui.GetStyle()
    local colors = style.Colors
    local clr = imgui.Col
    local ImVec4 = imgui.ImVec4
    style.WindowPadding = imgui.ImVec2(9, 5)
    style.WindowRounding = 10
    style.ChildWindowRounding = 10
    style.FramePadding = imgui.ImVec2(5, 3)
    style.FrameRounding = 6.0
    style.ItemSpacing = imgui.ImVec2(9.0, 3.0)
    style.ItemInnerSpacing = imgui.ImVec2(9.0, 3.0)
    style.IndentSpacing = 21
    style.ScrollbarSize = 6.0
    style.ScrollbarRounding = 13
    style.GrabMinSize = 17.0
    style.GrabRounding = 16.0
    style.WindowTitleAlign = imgui.ImVec2(0.5, 0.5)
    style.ButtonTextAlign = imgui.ImVec2(0.5, 0.5)
    colors[clr.Text]                   = ImVec4(0.05, 0.05, 0.05, 1.00);
    colors[clr.TextDisabled]           = ImVec4(0.29, 0.29, 0.29, 1.00);
    colors[clr.WindowBg]               = ImVec4(1.00, 1.00, 1.00, 1.00);
    colors[clr.ChildWindowBg]          = ImVec4(1.00, 1.00, 1.00, 1.00);
    colors[clr.PopupBg]                = ImVec4(1.00, 1.00, 1.00, 0.90);
    colors[clr.Border]                 = ImVec4(1.00, 1.00, 1.00, 1.00);
    colors[clr.BorderShadow]           = ImVec4(1.00, 1.00, 1.00, 0.10);
    colors[clr.FrameBg]                = ImVec4(0.90, 0.90, 0.90, 1.00);
    colors[clr.FrameBgHovered]         = ImVec4(0.80, 0.80, 0.80, 1.00);
    colors[clr.FrameBgActive]          = ImVec4(0.75, 0.75, 0.75, 1.00);
    colors[clr.TitleBg]                = ImVec4(1.00, 1.00, 1.00, 1.00);
    colors[clr.TitleBgActive]          = ImVec4(1.00, 1.00, 1.00, 1.00);
    colors[clr.TitleBgCollapsed]       = ImVec4(1.00, 1.00, 1.00, 1.00);
    colors[clr.MenuBarBg]              = ImVec4(1.00, 1.00, 1.00, 1.00);
    colors[clr.ScrollbarBg]            = ImVec4(1.00, 1.00, 1.00, 1.00);
    colors[clr.ScrollbarGrab]          = ImVec4(0.36, 0.36, 0.36, 1.00);
    colors[clr.ScrollbarGrabHovered]   = ImVec4(0.18, 0.22, 0.25, 1.00);
    colors[clr.ScrollbarGrabActive]    = ImVec4(0.24, 0.24, 0.24, 1.00);
    colors[clr.ComboBg]                = ImVec4(0.61, 0.61, 0.61, 1.00);
    colors[clr.CheckMark]              = ImVec4(0.42, 0.42, 0.42, 1.00);
    colors[clr.SliderGrab]             = ImVec4(0.51, 0.51, 0.51, 1.00);
    colors[clr.SliderGrabActive]       = ImVec4(0.65, 0.65, 0.65, 1.00);
    colors[clr.Button]                 = ImVec4(0.52, 0.52, 0.52, 0.83);
    colors[clr.ButtonHovered]          = ImVec4(0.58, 0.58, 0.58, 0.83);
    colors[clr.ButtonActive]           = ImVec4(0.44, 0.44, 0.44, 0.83);
    colors[clr.Header]                 = ImVec4(0.65, 0.65, 0.65, 1.00);
    colors[clr.HeaderHovered]          = ImVec4(0.73, 0.73, 0.73, 1.00);
    colors[clr.HeaderActive]           = ImVec4(0.53, 0.53, 0.53, 1.00);
    colors[clr.Separator]              = ImVec4(0.46, 0.46, 0.46, 1.00);
    colors[clr.SeparatorHovered]       = ImVec4(0.45, 0.45, 0.45, 1.00);
    colors[clr.SeparatorActive]        = ImVec4(0.45, 0.45, 0.45, 1.00);
    colors[clr.ResizeGrip]             = ImVec4(0.23, 0.23, 0.23, 1.00);
    colors[clr.ResizeGripHovered]      = ImVec4(0.32, 0.32, 0.32, 1.00);
    colors[clr.ResizeGripActive]       = ImVec4(0.14, 0.14, 0.14, 1.00);
    colors[clr.CloseButton]            = ImVec4(0.40, 0.39, 0.38, 0.16);
    colors[clr.CloseButtonHovered]     = ImVec4(0.40, 0.39, 0.38, 0.39);
    colors[clr.CloseButtonActive]      = ImVec4(0.40, 0.39, 0.38, 1.00);
    colors[clr.PlotLines]              = ImVec4(0.61, 0.61, 0.61, 1.00);
    colors[clr.PlotLinesHovered]       = ImVec4(1.00, 1.00, 1.00, 1.00);
    colors[clr.PlotHistogram]          = ImVec4(0.70, 0.70, 0.70, 1.00);
    colors[clr.PlotHistogramHovered]   = ImVec4(1.00, 1.00, 1.00, 1.00);
    colors[clr.TextSelectedBg]         = ImVec4(0.62, 0.62, 0.62, 1.00);
    colors[clr.ModalWindowDarkening]   = ImVec4(0.26, 0.26, 0.26, 0.60);
end
setLightStyle()